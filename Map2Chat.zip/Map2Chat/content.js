let defaultMessage = '';
let defaultCountryCode = '+880';

// Load stored defaults
chrome.storage.local.get(['defaultMessage', 'defaultCountryCode'], data => {
  if (data.defaultMessage) defaultMessage = data.defaultMessage;
  if (data.defaultCountryCode) defaultCountryCode = data.defaultCountryCode;
});

// Function: create WhatsApp button
function createWhatsAppButton(companyName, phoneNumber) {
  const btn = document.createElement('button');
  const icon = document.createElement('img');
  icon.src = chrome.runtime.getURL('icons/whatsapp.png');
  btn.textContent = 'Send Message';
  btn.className = 'whatsapp-btn';
  Object.assign(btn.style, {
    marginLeft: '10px',
    backgroundColor: '#25D366',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    padding: '6px 10px',
    cursor: 'pointer',
    fontWeight: '600',
    fontSize: '13px',
    transition: '0.2s',
  });

  btn.addEventListener(
    'mouseover',
    () => (btn.style.backgroundColor = '#128C7E')
  );
  btn.addEventListener(
    'mouseout',
    () => (btn.style.backgroundColor = '#25D366')
  );

  btn.addEventListener('click', () => {
    let finalNumber = phoneNumber.replace(/\D/g, '');
    if (!finalNumber.startsWith('+') && !finalNumber.startsWith('00')) {
      finalNumber = defaultCountryCode.replace(/\D/g, '') + finalNumber;
    }
    const msg = encodeURIComponent(
      defaultMessage.replace('{company}', companyName)
    );
    window.open(`https://wa.me/${finalNumber}?text=${msg}`);
  });

  return btn;
}

// Inject button beside business name
function injectWhatsAppButton() {
  const nameEl = document.querySelector('h1.DUwDvf span, h1.DUwDvf');
  const phoneEl = document.querySelector('a[href^="tel:"]');

  if (!nameEl || !phoneEl) return;
  if (document.querySelector('.whatsapp-btn')) return;

  const companyName = nameEl.innerText.trim();
  const phoneNumber = phoneEl.getAttribute('href').replace('tel:', '');

  const btn = createWhatsAppButton(companyName, phoneNumber);
  const parent = nameEl.closest('h1') || nameEl.parentElement;

  if (parent) {
    parent.style.display = 'flex';
    parent.style.alignItems = 'center';
    parent.appendChild(btn);
  }
}

// Use MutationObserver + delay to catch changes
let timeout;
const observer = new MutationObserver(() => {
  clearTimeout(timeout);
  timeout = setTimeout(() => injectWhatsAppButton(), 1000);
});
observer.observe(document.body, { childList: true, subtree: true });

// Re-check every few seconds (extra safety)
setInterval(injectWhatsAppButton, 5000);

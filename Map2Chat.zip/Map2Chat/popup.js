const country = document.getElementById('countryCode');
const message = document.getElementById('message');

chrome.storage.local.get(['defaultMessage', 'defaultCountryCode'], data => {
  if (data.defaultMessage) message.value = data.defaultMessage;
  if (data.defaultCountryCode) country.value = data.defaultCountryCode;
});

document.getElementById('saveBtn').addEventListener('click', () => {
  chrome.storage.local.set(
    {
      defaultMessage: message.value,
      defaultCountryCode: country.value,
    },
    () => alert('✅ Saved Successfully!')
  );
});
